import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def isExistProduct = property.get('isExistProduct');
    def productId = message.getHeaders().get('productIdentifier');
    
    if (isExistProduct) {
        println("Processing request for valid product ID: " + productId);
    } else {
        println("Invalid product ID received: " + productId);
        message.setBody(property.get('errorResponse'));
    }
    
    return message;
}