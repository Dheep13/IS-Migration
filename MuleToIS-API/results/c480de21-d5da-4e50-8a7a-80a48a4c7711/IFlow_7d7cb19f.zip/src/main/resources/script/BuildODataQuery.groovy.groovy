import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def productId = message.getHeaders().get('productIdentifier');
    
    // Only build the query if the product is valid
    if (message.getProperty('isExistProduct')) {
        def filterParam = "ProductId eq '" + productId + "'";
        def selectParam = "ProductId,Category,CategoryName,CurrencyCode,DimensionDepth,DimensionHeight,DimensionUnit,DimensionWidth,LongDescription,Name,PictureUrl,Price,QuantityUnit,ShortDescription,SupplierId,Weight,WeightUnit";
        
        message.setHeader('filterParam', filterParam);
        message.setHeader('selectParam', selectParam);
    }
    
    return message;
}