def productIdentifiers = property.get("odata.productIdentifiers").split(",")
def productId = message.getHeaders().get("productIdentifier")
def isValid = productIdentifiers.find { it == productId } != null

// Set the result as a property
map = [:]
map.put("isExistProduct", isValid)

return map