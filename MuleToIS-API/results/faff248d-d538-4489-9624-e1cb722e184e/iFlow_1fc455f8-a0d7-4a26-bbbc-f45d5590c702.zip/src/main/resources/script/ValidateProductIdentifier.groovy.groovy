def productIdentifiers = property.get('odata.productIdentifiers').split(',');
def requestedId = message.getHeaders().get('productIdentifier');

def isValid = productIdentifiers.find { it == requestedId } != null;

property.put('isExistProduct', isValid);
return message;