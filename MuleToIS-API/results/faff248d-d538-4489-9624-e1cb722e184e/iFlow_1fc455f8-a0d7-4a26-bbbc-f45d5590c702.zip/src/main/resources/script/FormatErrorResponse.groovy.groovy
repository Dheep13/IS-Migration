import groovy.json.JsonBuilder;

def requestedId = message.getHeaders().get('productIdentifier');

def errorResponse = [
    status: "error",
    message: "The product identifier " + requestedId + " was not found.",
    errorCode: "PRODUCT_NOT_FOUND"
];

def jsonBuilder = new JsonBuilder(errorResponse);
message.setBody(jsonBuilder.toString());
return message;