def productIdentifiers = property.get("odata.productIdentifiers").split(",")
def productId = message.getHeaders().get("productIdentifier")
def isExistProduct = productIdentifiers.find { it == productId } != null
message.setProperty("isExistProduct", isExistProduct)
return message