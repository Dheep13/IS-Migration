def productIdentifiers = properties.get("odata.productIdentifiers").split(",")
def requestedIdentifier = message.getProperty("productIdentifier")
def isValid = productIdentifiers.any { it == requestedIdentifier }
message.setProperty("isExistProduct", isValid)
return message