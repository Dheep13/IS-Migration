import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def isValid = message.getProperty('isValidProduct');
    def productId = message.getHeaders().get('productIdentifier');
    
    // Store productIdentifier in a property for use in OData query
    message.setProperty('productIdentifier', productId);
    
    // Log the request
    if (isValid) {
        def logMessage = "Processing valid request for product ID: " + productId;
        println(logMessage);
    } else {
        def logMessage = "Invalid product ID received: " + productId;
        println(logMessage);
    }
    
    return message;
}