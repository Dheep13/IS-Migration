def productIdentifiers = property.get("odata.productIdentifiers").split(",")
def requestedId = property.get("productIdentifier")
def isExistProduct = productIdentifiers.any { it == requestedId }
property.set("isExistProduct", isExistProduct.toString())
return message