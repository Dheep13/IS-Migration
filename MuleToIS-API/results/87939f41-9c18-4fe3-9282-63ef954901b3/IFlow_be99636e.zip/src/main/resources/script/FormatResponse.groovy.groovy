if (!message.getProperty('isExistProduct')) {
    def errorResponse = '{"status": "error", "message": "The product identifier ' + message.getHeaders().get('productIdentifier') + ' was not found.", "errorCode": "PRODUCT_NOT_FOUND"}';
    message.setBody(errorResponse);
    message.setHeader('Content-Type', 'application/json');
} else {
    message.setHeader('Content-Type', 'application/json');
}
return message;