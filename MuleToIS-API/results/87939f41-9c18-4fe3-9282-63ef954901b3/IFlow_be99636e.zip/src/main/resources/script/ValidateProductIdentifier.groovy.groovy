def productIdentifiers = property.get('odata.productIdentifiers').split(',');
def requestedProductId = message.getHeaders().get('productIdentifier');
def isValid = productIdentifiers.contains(requestedProductId);
message.setProperty('isExistProduct', isValid);
return message;