import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;

def Message processData(Message message) {
    def body = message.getBody(String);
    def isExistProduct = message.getProperty("isExistProduct");
    
    if (isExistProduct != null && isExistProduct.equals("true")) {
        // Process successful response
        def jsonSlurper = new JsonSlurper();
        def payload = jsonSlurper.parseText(body);
        
        // Just pass through the payload as is
        message.setBody(new JsonBuilder(payload).toString());
    } else {
        // Create error response
        def productIdentifier = message.getProperty("productIdentifier");
        def errorResponse = [
            status: "error",
            message: "The product identifier " + productIdentifier + " was not found.",
            errorCode: "PRODUCT_NOT_FOUND"
        ];
        
        message.setBody(new JsonBuilder(errorResponse).toString());
        message.setHeader("Content-Type", "application/json");
    }
    
    return message;
}