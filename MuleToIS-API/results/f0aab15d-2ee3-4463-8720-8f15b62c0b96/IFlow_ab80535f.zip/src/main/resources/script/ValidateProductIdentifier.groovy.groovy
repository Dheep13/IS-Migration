import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def query = message.getHeaders().get("CamelHttpQuery");
    def productIdentifier = "";
    
    // Extract productIdentifier from query parameters
    if (query != null && query.contains("productIdentifier=")) {
        def params = query.split("&");
        for (param in params) {
            if (param.startsWith("productIdentifier=")) {
                productIdentifier = param.substring("productIdentifier=".length());
                break;
            }
        }
    }
    
    // Get configured valid product identifiers
    def validProductIds = properties.get("odata.productIdentifiers").split(",");
    
    // Check if the provided product identifier is valid
    boolean isValid = false;
    for (validId in validProductIds) {
        if (validId.trim().equals(productIdentifier)) {
            isValid = true;
            break;
        }
    }
    
    // Set the validation result as a property
    message.setProperty("isProductValid", isValid);
    
    return message;
}