import groovy.json.JsonOutput

def productId = property.get("productIdentifier")
def response = [
    status: "error",
    message: "The product identifier " + productId + " was not found.",
    errorCode: "PRODUCT_NOT_FOUND"
]

def jsonResponse = JsonOutput.toJson(response)
message.setBody(jsonResponse)
return message