def productIdentifiers = property.get("odata.productIdentifiers").split(",")
def requestedProductId = message.getHeaders().get("productIdentifier")
property.put("productIdentifier", requestedProductId)
boolean isValid = productIdentifiers.any { it == requestedProductId }
property.put("isExistProduct", isValid)
return message