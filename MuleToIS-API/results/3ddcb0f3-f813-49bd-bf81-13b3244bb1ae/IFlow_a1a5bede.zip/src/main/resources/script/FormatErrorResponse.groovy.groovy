import groovy.json.JsonBuilder

def response = [:]
response.status = "error"
response.message = "The product identifier " + message.getProperty("productIdentifier") + " was not found."
response.errorCode = "PRODUCT_NOT_FOUND"

def builder = new JsonBuilder(response)
message.setBody(builder.toString())
return message