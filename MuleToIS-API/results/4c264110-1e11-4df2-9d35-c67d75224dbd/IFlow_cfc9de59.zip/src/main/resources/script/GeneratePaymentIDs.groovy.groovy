import groovy.json.*
import java.time.Instant

def jsonSlurper = new JsonSlurper()
def payload = jsonSlurper.parseText(message.getBody(String.class))

def sot = "PMT"
def random = new Random()
def generateId = { -> sot + (1..7).collect { random.nextInt(10) }.join('') }

def paymentsData = payload.Payments

paymentsData.each { payment ->
    payment.PaymentId = generateId()
    payment.CreationDateTime = Instant.now().toString()
}

def jsonBuilder = new JsonBuilder(payload)
return jsonBuilder.toString()