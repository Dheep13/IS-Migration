import groovy.json.*
import java.time.Instant

def jsonSlurper = new JsonSlurper()
def payload = jsonSlurper.parseText(message.getBody(String.class))

def response = [:]
response.PaymentIds = payload.PaymentIds
response.CancelDateTime = Instant.now().toString()

def jsonBuilder = new JsonBuilder(response)
return jsonBuilder.toString()