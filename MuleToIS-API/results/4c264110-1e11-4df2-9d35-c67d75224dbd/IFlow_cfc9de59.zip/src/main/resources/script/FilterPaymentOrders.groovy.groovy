import groovy.json.*

def jsonSlurper = new JsonSlurper()
def payload = jsonSlurper.parseText(message.getBody(String.class))
def properties = message.getProperties()

def paymentId = properties.get('paymentId')
def payeeName = properties.get('payeeName')
def amount = properties.get('amount')

def paymentOrders = payload.PaymentOrders

if (paymentId) {
    paymentOrders = paymentOrders.findAll { it.PaymentId.contains(paymentId) }
}

if (payeeName) {
    paymentOrders = paymentOrders.findAll { it.Payments.PayeeReference.PayeeName.contains(payeeName) }
}

if (amount) {
    paymentOrders = paymentOrders.findAll { it.Payments.PaymentDefinition.PaymentAmount.MaxAmount.contains(amount) }
}

def response = [PaymentOrders: paymentOrders]
def jsonBuilder = new JsonBuilder(response)
return jsonBuilder.toString()