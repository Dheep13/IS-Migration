import groovy.json.*

def jsonSlurper = new JsonSlurper()
def payload = jsonSlurper.parseText(message.getBody(String.class))

def bfr = "BFR-"
def random = new Random()
def generateId = { -> bfr + (1..7).collect { random.nextInt(10) }.join('') }

def accountsData = payload.InvestmentAccounts

if (accountsData.Beneficiaries.Primary) {
    accountsData.Beneficiaries.Primary.each { beneficiary ->
        beneficiary.BeneficiaryId = generateId()
    }
}

if (accountsData.Beneficiaries.Contingent) {
    accountsData.Beneficiaries.Contingent.each { beneficiary ->
        beneficiary.BeneficiaryId = generateId()
    }
}

def jsonBuilder = new JsonBuilder(payload)
return jsonBuilder.toString()