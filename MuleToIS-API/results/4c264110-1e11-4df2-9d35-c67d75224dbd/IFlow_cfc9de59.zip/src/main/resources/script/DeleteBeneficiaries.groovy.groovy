import groovy.json.*

def jsonSlurper = new JsonSlurper()
def payload = jsonSlurper.parseText(message.getBody(String.class))

def accountsData = payload.InvestmentAccounts
def response = [InvestmentAccounts: [:]]

response.InvestmentAccounts.AccountIds = accountsData.AccountIds
response.InvestmentAccounts.Beneficiaries = accountsData.Beneficiaries.collect { beneficiary ->
    [BeneficiaryId: beneficiary.BeneficiaryId, Status: "DELETED"]
}

def jsonBuilder = new JsonBuilder(response)
return jsonBuilder.toString()