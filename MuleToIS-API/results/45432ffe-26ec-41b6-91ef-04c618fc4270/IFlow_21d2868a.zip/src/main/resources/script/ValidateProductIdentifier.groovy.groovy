def productIdentifiers = property.get("odata.productIdentifiers").split(",")
def requestedId = message.getProperty("productIdentifier")
def isValid = productIdentifiers.find { it == requestedId } != null
message.setProperty("isExistProduct", isValid)
return message