def productId = message.getHeaders().get("productIdentifier");
def errorResponse = '{"status": "error", "message": "The product identifier ' + productId + ' was not found.", "errorCode": "PRODUCT_NOT_FOUND"}';
message.setBody(errorResponse);
message.setHeader("Content-Type", "application/json");
return message;