def productId = message.getHeaders().get("productIdentifier");
message.setProperty("SAP_OData_Filter", "ProductId eq '" + productId + "'");
message.setProperty("SAP_OData_Select", "ProductId,Category,CategoryName,CurrencyCode,DimensionDepth,DimensionHeight,DimensionUnit,DimensionWidth,LongDescription,Name,PictureUrl,Price,QuantityUnit,ShortDescription,SupplierId,Weight,WeightUnit");
return message;