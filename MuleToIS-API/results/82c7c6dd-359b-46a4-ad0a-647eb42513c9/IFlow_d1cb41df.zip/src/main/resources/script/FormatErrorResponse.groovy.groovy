import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def body = "";
    def productId = message.getHeaders().get("productIdentifier");
    
    if (message.getProperties().get("isProductValid") == false) {
        body = "{\"status\": \"error\", \"message\": \"The product identifier " + productId + " was not found.\", \"errorCode\": \"PRODUCT_NOT_FOUND\"}";
        message.setHeader("Content-Type", "application/json");
        message.setBody(body);
    }
    
    return message;
}