import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def productIdentifiers = properties.get("odata.productIdentifiers").split(",")
    def productId = message.getHeaders().get("productIdentifier")
    def isExistProduct = productIdentifiers.any { it == productId }
    
    message.setProperty("isExistProduct", isExistProduct)
    message.setProperty("productIdentifier", productId)
    
    return message;
}