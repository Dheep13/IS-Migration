import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def map = message.getProperties();
    def productIdentifier = message.getProperty("productIdentifier");
    def isExistProduct = message.getProperty("isExistProduct");
    
    def logMessage = "Processing request for product: " + productIdentifier;
    logMessage += ", Valid product: " + isExistProduct;
    
    println(logMessage);
    return message;
}