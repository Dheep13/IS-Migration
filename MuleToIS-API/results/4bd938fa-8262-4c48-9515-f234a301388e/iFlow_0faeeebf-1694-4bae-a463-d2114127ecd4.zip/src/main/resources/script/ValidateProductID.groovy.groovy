import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def query = message.getHeaders().get("CamelHttpQuery");
    def productIdentifier = "";
    
    if (query != null && query.contains("productIdentifier=")) {
        productIdentifier = query.split("productIdentifier=")[1];
        if (productIdentifier.contains("&")) {
            productIdentifier = productIdentifier.split("&")[0];
        }
    }
    
    message.setProperty("productIdentifier", productIdentifier);
    
    def validProducts = message.getProperty("odata.productIdentifiers").split(",");
    
    def isValid = false;
    for (product in validProducts) {
        if (product.trim() == productIdentifier) {
            isValid = true;
            break;
        }
    }
    
    message.setProperty("isExistProduct", isValid);
    return message;
}