import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonBuilder;

def Message processData(Message message) {
    def productIdentifier = message.getProperty("productIdentifier");
    
    def errorResponse = [
        status: "error",
        message: "The product identifier " + productIdentifier + " was not found.",
        errorCode: "PRODUCT_NOT_FOUND"
    ];
    
    def jsonBuilder = new JsonBuilder(errorResponse);
    message.setBody(jsonBuilder.toString());
    message.setHeader("Content-Type", "application/json");
    
    return message;
}