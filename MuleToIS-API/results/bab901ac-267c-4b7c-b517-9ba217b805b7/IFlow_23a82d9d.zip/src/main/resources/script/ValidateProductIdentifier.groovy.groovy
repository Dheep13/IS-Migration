import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def body = message.getBody(String.class);
    def map = message.getProperties();
    def productIdentifier = map.get("productIdentifier");
    
    // Get configured product identifiers from property
    def validProductIds = map.get("odata.productIdentifiers").split(",");
    
    // Check if product identifier exists in the list
    boolean isExistProduct = false;
    for (String id : validProductIds) {
        if (id.trim().equals(productIdentifier)) {
            isExistProduct = true;
            break;
        }
    }
    
    // Set result as property
    map.put("isExistProduct", isExistProduct);
    
    return message;
}