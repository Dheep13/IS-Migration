import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processMessage(Message message) {
    // Get the message body
    def body = message.getBody(String.class);

    // Log the message
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
        messageLog.setStringProperty("Processing", "Processing in Check_Product_Exists");
        messageLog.addAttachmentAsString("Payload", body, "text/plain");
    }

    // Add a header to indicate processing
    message.setHeader("Processed-By", "Check_Product_Exists");

    return message;
}
