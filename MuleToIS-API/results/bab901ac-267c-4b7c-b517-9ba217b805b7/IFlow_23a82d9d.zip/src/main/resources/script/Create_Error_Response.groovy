import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processError(Message message) {
    // Get the message body
    def body = message.getBody(String.class);

    // Log the error
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
        messageLog.setStringProperty("Error", "Error occurred in Create_Error_Response");
        messageLog.addAttachmentAsString("Error payload", body, "text/plain");
    }

    // Set error response headers
    message.setHeader("HTTP_STATUS_CODE", "500");
    message.setHeader("Content-Type", "application/json");

    // Create error response
    def errorResponse = "{\"error\": \"An error occurred while processing the request\", \"component\": \"Create_Error_Response\"}";
    message.setBody(errorResponse);

    return message;
}
