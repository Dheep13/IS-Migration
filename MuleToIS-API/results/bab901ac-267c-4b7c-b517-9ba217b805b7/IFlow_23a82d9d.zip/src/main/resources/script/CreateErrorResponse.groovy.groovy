import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonBuilder;

def Message processData(Message message) {
    def map = message.getProperties();
    def productIdentifier = map.get("productIdentifier");
    
    // Create error response JSON
    def errorResponse = [
        status: "error",
        message: "The product identifier " + productIdentifier + " was not found.",
        errorCode: "PRODUCT_NOT_FOUND"
    ];
    
    // Convert to JSON string
    def jsonBuilder = new JsonBuilder(errorResponse);
    message.setBody(jsonBuilder.toString());
    
    // Set content type header
    map.put("Content-Type", "application/json");
    
    return message;
}