import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def isExistProduct = message.getProperties().get("isExistProduct");
    
    if (isExistProduct) {
        // Log success
        def productId = message.getHeaders().get("queryParams").get("productIdentifier");
        println("The request is processed and sent downstream with the product identifier (" + productId + ").");
        
        // Store productIdentifier as property for OData query
        message.setProperty("productIdentifier", productId);
        
        // Route to success path (OData call)
        message.setProperty("routeTo", "success");
    } else {
        // Log error
        def productId = message.getHeaders().get("queryParams").get("productIdentifier");
        println("The product identifier (" + productId + ") was not passed in the request or was passed incorrectly.");
        
        // Route to error path
        message.setProperty("routeTo", "error");
    }
    
    return message;
}