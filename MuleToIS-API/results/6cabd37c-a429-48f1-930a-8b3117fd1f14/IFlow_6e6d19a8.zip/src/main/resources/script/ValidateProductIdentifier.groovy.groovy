import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    def body = message.getBody(String.class);
    def headers = message.getHeaders();
    def properties = message.getProperties();
    
    // Get query parameters
    def map = message.getHeaders().get("SAP_MessageProcessingLogID");
    def productIdentifier = message.getProperty("productIdentifier");
    
    // Get allowed product identifiers from property
    def allowedProductIds = properties.get("odata.productIdentifiers").split(",");
    
    // Check if product identifier is in the allowed list
    boolean isValid = false;
    for (String id : allowedProductIds) {
        if (id.trim().equals(productIdentifier)) {
            isValid = true;
            break;
        }
    }
    
    // Set property for routing
    message.setProperty("isExistProduct", isValid);
    
    return message;
}