import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonBuilder;

def Message processData(Message message) {
    def body = message.getBody(String.class);
    def headers = message.getHeaders();
    def properties = message.getProperties();
    
    // Get product identifier from property
    def productIdentifier = message.getProperty("productIdentifier");
    
    // Create error response
    def errorResponse = [
        status: "error",
        message: "The product identifier " + productIdentifier + " was not found.",
        errorCode: "PRODUCT_NOT_FOUND"
    ];
    
    // Convert to JSON
    def jsonBuilder = new JsonBuilder(errorResponse);
    message.setBody(jsonBuilder.toString());
    
    // Set content type header
    message.setHeader("Content-Type", "application/json");
    
    return message;
}