import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def Message processData(Message message) {
    def body = message.getBody(String);
    def headers = message.getHeaders();
    def properties = message.getProperties();
    
    // Check if product validation failed
    if (properties.get("isValid") == false) {
        // Return error response
        def errorResponse = [
            status: "error",
            message: "The product identifier " + headers.get("productIdentifier") + " was not found.",
            errorCode: "PRODUCT_NOT_FOUND"
        ];
        message.setBody(JsonOutput.toJson(errorResponse));
        message.setHeader("Content-Type", "application/json");
        message.setHeader("HTTP_RESPONSE_STATUS", 404);
    } else {
        // Process successful response
        message.setHeader("Content-Type", "application/json");
        message.setHeader("HTTP_RESPONSE_STATUS", 200);
    }
    
    return message;
}