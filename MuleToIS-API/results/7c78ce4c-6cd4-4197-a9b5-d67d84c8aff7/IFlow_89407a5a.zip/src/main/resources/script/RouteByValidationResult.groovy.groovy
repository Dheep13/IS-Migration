import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def isValidProduct = message.getProperty('isValidProduct');
    
    if (isValidProduct) {
        // Route to OData call
        message.setProperty('routeTo', 'odata');
    } else {
        // Route to error response
        def productId = message.getHeaders().get('productIdentifier');
        def errorJson = '{"status": "error", "message": "The product identifier ' + productId + ' was not found.", "errorCode": "PRODUCT_NOT_FOUND"}';
        message.setBody(new String(errorJson));
        message.setProperty('routeTo', 'error');
    }
    
    return message;
}