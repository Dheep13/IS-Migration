import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String);
    def map = message.getProperties();
    def logger = map.get("logger");
    
    logger.addAttachmentAsString("Request for products list", body, "text/plain");
    
    return message;
}