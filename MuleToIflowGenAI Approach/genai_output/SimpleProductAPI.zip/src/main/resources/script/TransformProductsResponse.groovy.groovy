import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String);
    def jsonSlurper = new JsonSlurper();
    def products = jsonSlurper.parseText(body);
    
    // Transform the products data as needed
    def transformedProducts = products.collect { product ->
        [
            id: product.Id,
            name: product.Name,
            description: product.Description,
            price: product.Price
        ]
    }
    
    message.setBody(JsonOutput.toJson(transformedProducts));
    return message;
}