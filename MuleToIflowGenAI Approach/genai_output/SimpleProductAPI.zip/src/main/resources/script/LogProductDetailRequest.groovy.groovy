import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String);
    def map = message.getProperties();
    def logger = map.get("logger");
    def productId = map.get("productId");
    
    logger.addAttachmentAsString("Request for product ID: " + productId, body, "text/plain");
    
    return message;
}