import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String);
    def jsonSlurper = new JsonSlurper();
    def product = jsonSlurper.parseText(body);
    
    // Transform the product detail data as needed
    def transformedProduct = [
        id: product.Id,
        name: product.Name,
        description: product.Description,
        price: product.Price,
        category: product.Category,
        supplier: product.Supplier
    ]
    
    message.setBody(JsonOutput.toJson(transformedProduct));
    return message;
}